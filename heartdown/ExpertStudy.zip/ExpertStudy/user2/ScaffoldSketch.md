❤: ScaffoldSketch


Given a ScaffoldSketch model with an existing set of constraint functions, we will imagine that a user clicks on an edge or vertex and manipulates it. All adjacent edges or vertices may be affected by this change. They are "live" in an optimization process we run which updates the live vertex positions. The optimization re-uses the constraint functions determined in the original ScaffoldSketch model. That is, there are a set of constraint functions E_{pairwise} that take two line segments as input and compute the distance from satisfaction and a set of constraint functions E_{single} that take one line segment. In the future, we may want a threshold base on the user's manipulation to remove constraints that no longer seem relevant based on the manipulation.
One kind of constraint measures the difference in lengths between two lines ab and pq:

``` iheartla
`E_{length}`( V, a, b, p, q ) = (‖ V_a,* - V_b,* ‖/‖ V_p,* - V_q,*‖ -1)^2 where V ∈ ℝ^(m×3), a ∈ ℤ, b ∈ ℤ, p ∈ ℤ, q ∈ ℤ
```

where <span class="def:V"> $V$ is the points.</span>, <span class="def:a;b;p;q"> $a$, $b$, $p$, $q$ are the indices.</span>, <span class="def:E_{length}"> $E_{length}$ takes in points $V$ and the index $a$, $b$, $p$, $q$ returns length energy. </span>



Another measures whether two lines are parallel:
 
``` iheartla
`E_{parallel}`( V, a, b, p, q ) = (|((V_a,*-V_b,*)/‖ V_a,* - V_b,* ‖)⋅((V_p,*-V_q,*)/‖ V_p,* - V_q,* ‖)| - 1)² where V ∈ ℝ^(m×3), a ∈ ℤ, b ∈ ℤ, p ∈ ℤ, q ∈ ℤ
```

where <span class="def:E_{parallel}"> $E_{parallel}$ takes in points $V$ and the index $a$, $b$, $p$, $q$ returns parallel energy. </span>


Another measures whether two lines are perpendicular:

```iheartla
`E_{perpendicular}`( V, a, b, p, q ) = (|((V_a,*-V_b,*)/‖ V_a,* - V_b,* ‖)⋅((V_p,*-V_q,*)/‖ V_p,* - V_q,* ‖)|)² where V ∈ ℝ^(m×3), a ∈ ℤ, b ∈ ℤ, p ∈ ℤ, q ∈ ℤ
```

where <span class="def:E_{perpendicular}"> $E_{perpendicular}$ takes in points $V$ and the index $a$, $b$, $p$, $q$ returns perpendicular energy. </span>


Given a set of these functions and corresponding sets of positions given as indices into an array $ V_o ∈ ℝ^(n × 3)  $, we can find new positions via optimization:


``` iheartla
t = with  initial  `V_o` = `V₀`
min_( `V_o` ∈ ℝ^(n×3) ) `E_{len}`( `V_o`, L) + `E_{par}`(`V_o`, P) +`E_{per}`( `V_o`, Q) where 
`V₀` ∈ ℝ^(n×3)
L ∈ ℤ^(l × 4)
P ∈ ℤ^(p × 4)
Q ∈ ℤ^(q × 4)
```

where <span class="def:V_o"> $V_o$ is the subset of points to be optimized.</span>, <span class="def:V₀"> $V₀$ is the intial value of $V_o$.</span>, <span class="def:L;P;Q"> $L$, $P$, $Q$ are length, parallel and perpendicular indices.</span>, and <span class="def:t"> $t$ is energy equals to the sum of $E_{len}$, $E_{par}$ and $E_{per}$.</span>.



Since some vertices are fixed, function f is used to get the position of all vertices. In order to conveniently get the positionfor each energy, we can use several helper functions to index the full position matrix.

```iheartla
`E_{len}`( `V_o`, L) = ∑_i `E_{length}`( f(`V_o`), L_i,1, L_i,2, L_i,3, L_i,4  ) where `V_o` ∈ ℝ^(n × 3), L ∈ ℤ^(l × 4)
where
m ∈ ℤ: m is the number of points 
f : ℝ^(n × 3) → ℝ^( m × 3 )
```

where <span class="def:f"> $f$ maps $V$ to $V_o$</span>, and <span class="def:E_{len}">$E_{len}$ takes $V_o$, $L$ and sums all the length energy value. </span>
 
``` iheartla
`E_{par}`( `V_o`, P) = ∑_i `E_{parallel}`( f(`V_o`), P_i,1, P_i,2, P_i,3, P_i,4  ) where `V_o` ∈ ℝ^(n × 3), P ∈ ℤ^(p × 4)
```

where <span class="def:E_{par}"> $E_{par}$ takes $V_o$, $P$ and sums all the parallel energy value. </span>


``` iheartla
`E_{per}`( `V_o`, Q) = ∑_i `E_{perpendicular}`( f(`V_o`), Q_i,1, Q_i,2, Q_i,3, Q_i,4 )  where `V_o` ∈ ℝ^(n × 3), Q ∈ ℤ^(q × 4)
```
where <span class="def:E_{per}"> $E_{per}$ takes $V_o$, $Q$ and sums all the perpendicular energy value. </span>




