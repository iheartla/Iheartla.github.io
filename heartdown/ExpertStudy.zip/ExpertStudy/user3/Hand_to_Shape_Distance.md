---

full_paper: False

---

❤: HandToShapeDistance

Let's say we have a hand made of five fingers and we want to know if it's intersecting a shape. Assume we can detect where the five fingertips intersect with the shape. And below we will analyse the distance of fingertips to a cuboid.



# Distance to Cuboid

Assume we have two lists of 3D points with same length, in which $ps$ includes the start points of eight edges, and $pe$ includes all end points of edges. The following formula <span class="def"> $f$ calculates the distance from one point to an edge </span> in 3 conditions: closest to start or end point, or perpendicular to the edge. <span class="def">$ps_i$ is the start point of edge $i$ </span>, and <span class="def"> $pe_i$ represents the 3D position of endpoint of edge $i$ </span>. <span class="def"> $V_j$ represents the 3D position of fingertip $j$ </span>. <span class="def">  $A$ is the matrix storing the distance between fingertips to edges $j$ </span>. <span class="def"> $f$ represents the 3D position of fingertip $j$ </span>.






``` iheartla



f(`ps_i`, `pe_i`, `V_j`) = { ‖`V_j` - `ps_i`‖ if (`pe_i` - `ps_i`) ⋅ (`V_j` - `ps_i`) > 0

                                 ‖`V_j` - `pe_i`‖ if (`ps_i` - `pe_i`) ⋅ (`V_j` - `pe_i`) > 0

                                 (`pe_i` - `ps_i`)⋅ (`V_j` - `ps_i`)/‖`pe_i` - `ps_i`‖  otherwise where `V_j`, `ps_i`, `pe_i` ∈ ℝ^3  , i,j ∈ ℝ



A_ij = f(ps_i, pe_i, V_j)

where

ps_i ∈ ℝ^3: lists of position of start points of line segments

pe_i ∈ ℝ^3: lists of position of end points of line segments

V_j ∈ ℝ^3 : lists of position of five fingertips

```