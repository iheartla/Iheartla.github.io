---
full_paper: True
title: Time-Parallel Frame Discrete Elastic Rods
author:
- name: Anonymized
  affiliation: Anonymized
---
❤: energy

# Introduction
In this document, we showcase how IHeartLA improves the clarity of a paper with numerous varibles. Discrete Elastic Rods is a perfect example of how we can boost productivity with IHeartLA. Compare to the original [@bergou2008discrete], this document describes a model of discrete elastic rod using time-parallel frame [@bergou2010viscous] instead of space-parallel frame and adds a stretching energy term.

# Discretization
Let there be <span class="def"> $nv$ is the number of vertices</span>, and that implies <span class="def"> $ne$ is the number of edges/segments </span>, where $ne = nv - 1$.

On every segment, there is a orthogonal frame indicating the direction/orientation/twist of that segment where <span class="def"> $d_1$ and $d_2$ are orthogonal directors of every segment on the center-line </span>, and <span class="def">$t$ is the unit normal </span>.

To simulate the dynamics, we need to define the **rest state** of the rod. Intuitively, we need to save **rest state** configuration of the rod, which composes of <span class="def"> rest position $\bar{x}$ </span>, <span class="def"> rest orthogonal directors $\bar{d_1}$ and $\bar{d_2}$ </span>. Note that we want the save the whole orthogonal frame so we can have rest rotational information, but we can recover rest unit normal the rest center-line position $\bar{x}$.

For every segment, we assume the cross-section to be an oval. In this note, we include <span class="def"> $a_i$ and $b_i$ as the two axies of the ellipse at the $i^{th}$ segment </span>, but we also assume $a_i = b_i = r$ so that the cross-section is a circle. Therefore, we have <span class="def"> the area of the node cross-section $A_i$ </span>,
```iheartla
A_i = π a_i b_i

where
a_i ∈ ℝ
b_i ∈ ℝ
```

# Discrete Energy
To accurately model a rod, we need to consider its response to bending and stretching. In addition, we also need a rotational energy, or twist energy, to model twists accumulated across the rod. In this section, we show the three energy equation in discrete settings:

## Bending Energy
Define <span class="def"> bending energy $E_b$ </span>
```iheartla
`E_b` = 1/2 ∑_i 1/`\bar{l}`_i(B_i,1,1 (`κ_2`_i - `\bar{κ}_2`_i)^2 + B_i,2,2 (`κ_1`_i - `\bar{κ}_1`_i)^2)

where
`\bar{l}`_i ∈ ℝ
E ∈ ℝ
```
where
```iheartla
`κ_1`_i = `κb`_i ⋅ (`\tilde{d_2}`_i + `d_2`_i)/2
`κ_2`_i = -`κb`_i ⋅ (`\tilde{d_1}`_i + `d_1`_i)/2
`\bar{κ}_1`_i = `\bar{κb}`_i ⋅ (`\bar{\tilde{d_2}}`_i + `\bar{d_2}`_i)/2
`\bar{κ}_2`_i = -`\bar{κb}`_i ⋅ (`\bar{\tilde{d_1}}`_i + `\bar{d_1}`_i)/2

where
`κb`_i ∈ ℝ^3
`\bar{κb}`_i ∈ ℝ^3
`d_1`_i ∈ ℝ^3
`d_2`_i ∈ ℝ^3
`\tilde{d_1}`_i ∈ ℝ^3 : tilde d1 is d1 shifted left by one 
`\tilde{d_2}`_i ∈ ℝ^3 : tilde d2 is d2 shifted left by one
`\bar{d_1}`_i ∈ ℝ^3
`\bar{d_2}`_i ∈ ℝ^3
`\bar{\tilde{d_1}}`_i ∈ ℝ^3 : bar tilde d1 is bar d1 shifted left by one 
`\bar{\tilde{d_2}}`_i ∈ ℝ^3 : bar tilde d2 is bar d2 shifted left by one
```
<span class="def"> $κb$ being curvature binormal</span>, <span class="def"> $\bar{κb}$ being rest curvature binormal</span>, <span class="def"> $κ_1$ and $κ_2$ being curvature vectors </span>, <span class="def"> $\bar{κ}_1$ and $\bar{κ}_2$ being rest curvature vectors </span>, <span class="def"> $B$ is the bending stiffness matrix </span>, which ❤ B_i = EA_i/4 [a_i^2 0; 0 b_i^2] ❤, <span class="def"> $\bar{l}$ is the voronoi length </span>, and <span class="def"> $E$ is the Young's modulus </span>.

## Twisting Energy
Define <span class="def"> twisting energy $E_t$ </span>
```iheartla
`E_t` = 1/2 ∑_i β_i/`\bar{l}`_i(m_i - `\bar{m}`_i)^2
β_i = GA_i(a_i^2+b_i^2)/4

where
G ∈ ℝ
m_i ∈ ℝ
`\bar{m}`_i ∈ ℝ
```
where <span class="def"> $G$ is the shear modulus</span>, <span class="def"> $β_i$ is the twisting modulus</span>, <span class="def"> $m$ is the twist</span>, <span class="def"> $\bar{m}$ is the rest twist</span>, <span class="def"> $\bar{m}$ is the rest twist</span>, and <span class="def">$\overline{l}_i$ being the voronoi length </span>.

## Stretching Energy
Define <span class="def"> stretching energy $E_s$ </span>
```iheartla
`E_s` = 1/2 ∑_j `k_s` (‖e_j‖ / ‖`\bar{e}`_j‖ - 1)^2 ‖`\bar{e}`_j‖

where
e_j ∈ ℝ^3
`\bar{e}`_j ∈ ℝ^3
`k_s` ∈ scalar  
```
where <span class="def"> $k_s$ is the stretching coefficient </span>, <span class="def">$e$ being the edge length </span>, and <span class="def">$\bar{e}$ being the rest edge length </span>.