function ret_set = NonZeros(target)
    [ret_set, col] = find(target);
end