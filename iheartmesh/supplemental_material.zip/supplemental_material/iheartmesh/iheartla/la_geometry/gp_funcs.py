# define the keys of builtin function names for geometry processing
FACE_OF_EDGES = 'faces_of_edge'
FACE_NORMAL = 'face_normal'
DIHEDRAL = 'dihedral'