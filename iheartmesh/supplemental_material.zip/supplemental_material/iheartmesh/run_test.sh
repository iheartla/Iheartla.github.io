python3 -m unittest discover  -s test
rm test/*.cpp
# rm test/*.m
