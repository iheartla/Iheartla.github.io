1. Create and edit `icon.pdf`
2. Export a 1024x1024 png as `icon.png`
3. Run `make_icns icon.png`
